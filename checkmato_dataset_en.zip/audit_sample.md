# CheckMato Human Audit Sample (10% Random Sample)
Total sample size: 9 claims

| Case ID | Claim ID | Context | Expected | Evidence Quote | Notes |
|---|---|---|---|---|---|
| en-health-001 | c003 | Principal Investigator Dr. Rachel Vance presented the findings at the European Neurology Congress. | supported | Principal Investigator Dr. Rachel Vance presented the findings at the European Neurology Congress. |  |
| en-biz-002 | c004 | Inventory turnover ratio improved to 4.2 cycles per annum. | supported | Inventory turnover ratio improved to 4.2 cycles per annum. |  |
| en-tech-002 | c001 | Lumina Optical Networks sustained 800 Gbps transmission across a 1,200-kilometer fiber link. | supported | Lumina Optical Networks sustained 800 Gbps transmission across a 1,200-kilometer fiber link. |  |
| en-policy-002 | c005 | Through deep-well recharge basins coupled with gravity-fed riparian wetlands, groundwater replenishment reached 850 acre-feet per quarter. | supported | Through deep-well recharge basins coupled with gravity-fed riparian wetlands, groundwater replenishment reached 850 acre-feet per quarter. |  |
| en-health-002 | c001 | Valenta Therapeutics reported 62% progression-free survival in advanced oncology cohorts. | supported | Valenta Therapeutics reported 62% progression-free survival in advanced oncology cohorts. |  |
| en-tech-002 | c004 | Priya Patel confirmed optical signal-to-noise ratio exceeded 26 dB under test conditions. | supported | Priya Patel confirmed optical signal-to-noise ratio exceeded 26 dB under test conditions. |  |
| en-tech-001 | c001 | NexaGrid Systems achieved distributed ledger throughput of 45,000 transactions per second. | supported | NexaGrid Systems achieved distributed ledger throughput of 45,000 transactions per second. |  |
| en-tech-001 | c007 | The protocol automatically calibrated bandwidth using quantum-resistant cryptographic handshakes. | no_source |  | Not in library. |
| en-tech-001 | c003 | Chief Architect Dr. Aris Thorne published the core protocol specifications in May 2023. | supported | Chief Architect Dr. Aris Thorne published the core protocol specifications in May 2023. |  |