#!/usr/bin/env python3
"""
CheckMato Benchmark Dataset Validator
Implements Section 9 (QA and acceptance) of DATASET_PLAN_EN.md / DATASET_PLAN_ZH.md.

Usage:
    python3 scripts/validate_dataset.py --dataset-dir <path_to_dataset> [--audit-sample 0.10]
"""

import argparse
import json
import os
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
import random

def normalize_text(text: str) -> str:
    """Normalize whitespace and punctuation for verbatim substring matching."""
    if not text:
        return ""
    # Replace multiple whitespace/newlines with single space
    text = re.sub(r'\s+', ' ', text)
    # Strip common enclosing quotes
    text = text.strip(' "\'“”‘’')
    return text.strip()

def find_source_file(library_dir: Path, source_id: str) -> Path | None:
    """Locate source file by source_id allowing standard extensions."""
    for ext in ["", ".md", ".txt", ".pdf", ".docx"]:
        candidate = library_dir / f"{source_id}{ext}"
        if candidate.is_file():
            return candidate
    # Case-insensitive or prefix search if exact name didn't match
    for f in library_dir.iterdir():
        if f.is_file() and f.stem.lower() == source_id.lower():
            return f
    return None

def read_source_lines(file_path: Path) -> list[str]:
    """Read lines of source file. For PDF/docx, read text representation if available."""
    try:
        return file_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception as e:
        return []

class DatasetValidator:
    def __init__(self, dataset_dir: Path, sample_rate: float = 0.10):
        self.dataset_dir = dataset_dir
        self.sample_rate = sample_rate
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.stats = {
            "cases_by_split": Counter(),
            "cases_by_domain": Counter(),
            "claims_by_expected": Counter(),
            "claims_by_difficulty": Counter(),
            "footnotes_by_expected": Counter(),
            "total_checkable": 0,
            "total_prose": 0,
            "total_footnotes": 0,
        }
        self.all_claims_for_audit = []

    def log_error(self, case_id: str, claim_id: str, msg: str):
        self.errors.append(f"[{case_id}] [claim:{claim_id or 'N/A'}] ERROR: {msg}")

    def log_warning(self, case_id: str, claim_id: str, msg: str):
        self.warnings.append(f"[{case_id}] [claim:{claim_id or 'N/A'}] WARN: {msg}")

    def validate(self) -> bool:
        manifest_path = self.dataset_dir / "manifest.jsonl"
        if not manifest_path.exists():
            # Check if cases directory exists directly
            manifest_path = self.dataset_dir / "cases" / "manifest.jsonl"
            if not manifest_path.exists():
                self.errors.append(f"manifest.jsonl not found in {self.dataset_dir}")
                return False

        print(f"Loading manifest from {manifest_path}...")
        cases = []
        with open(manifest_path, "r", encoding="utf-8") as f:
            for idx, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                try:
                    case = json.loads(line)
                    cases.append(case)
                except json.JSONDecodeError as e:
                    self.errors.append(f"manifest.jsonl line {idx}: Invalid JSON - {e}")

        print(f"Found {len(cases)} cases in manifest. Validating individual cases...\n")
        for case in cases:
            self.validate_case(case)

        self.validate_dataset_distributions(cases)
        return len(self.errors) == 0

    def validate_case(self, case: dict):
        case_id = case.get("case_id", "unknown")
        split = case.get("split", "dev")
        domain = case.get("domain", "general")
        lang = case.get("language", "en")

        self.stats["cases_by_split"][split] += 1
        if split != "adversarial":
            self.stats["cases_by_domain"][domain] += 1

        # Check paths
        draft_rel = case.get("draft", f"cases/{case_id}/draft.md")
        library_rel = case.get("library", f"cases/{case_id}/library")
        
        draft_path = self.dataset_dir / draft_rel
        if not draft_path.exists():
            draft_path = self.dataset_dir / "cases" / case_id / "draft.md"
        if not draft_path.is_file():
            self.log_error(case_id, "", f"Draft file not found at {draft_rel}")

        library_path = self.dataset_dir / library_rel
        if not library_path.exists():
            library_path = self.dataset_dir / "cases" / case_id / "library"
        if not library_path.is_dir():
            self.log_error(case_id, "", f"Library folder not found at {library_rel}")
            source_files = {}
        else:
            files = [f for f in library_path.iterdir() if f.is_file()]
            if len(files) < 3 and split != "adversarial":
                self.log_warning(case_id, "", f"Library contains only {len(files)} files (expected 3-8)")
            source_files = {f.stem: f for f in files}

        # Check expected.jsonl
        expected_path = self.dataset_dir / "cases" / case_id / "expected.jsonl"
        if not expected_path.exists():
            expected_path = draft_path.parent / "expected.jsonl"
        
        if not expected_path.is_file():
            self.log_error(case_id, "", f"expected.jsonl not found for case {case_id}")
            return

        claim_ids = set()
        case_checkable_count = 0
        case_footnote_count = 0

        with open(expected_path, "r", encoding="utf-8") as f:
            for line_no, raw_line in enumerate(f, start=1):
                raw_line = raw_line.strip()
                if not raw_line:
                    continue
                try:
                    record = json.loads(raw_line)
                except json.JSONDecodeError as e:
                    self.log_error(case_id, f"line_{line_no}", f"JSON parse error: {e}")
                    continue

                claim_id = record.get("claim_id")
                if not claim_id:
                    self.log_error(case_id, f"line_{line_no}", "Missing claim_id")
                    continue

                if claim_id in claim_ids:
                    self.log_error(case_id, claim_id, f"Duplicate claim_id in case: {claim_id}")
                claim_ids.add(claim_id)

                claim_type = record.get("claim_type", "")
                expected = record.get("expected", "")

                if claim_type == "footnote":
                    case_footnote_count += 1
                    self.stats["total_footnotes"] += 1
                    self.stats["footnotes_by_expected"][expected] += 1
                    self.validate_footnote(case_id, record, library_path)
                elif expected == "not_checked":
                    self.stats["total_prose"] += 1
                    self.validate_prose(case_id, record)
                else:
                    case_checkable_count += 1
                    self.stats["total_checkable"] += 1
                    self.stats["claims_by_expected"][expected] += 1
                    diff = record.get("difficulty")
                    if diff:
                        self.stats["claims_by_difficulty"][diff] += 1
                    self.validate_checkable_claim(case_id, record, library_path)
                    self.all_claims_for_audit.append((case_id, record))

        expected_claims = case.get("claims")
        if expected_claims is not None and expected_claims != case_checkable_count:
            self.log_warning(case_id, "", f"Manifest claims ({expected_claims}) != actual checkable claims in expected.jsonl ({case_checkable_count})")

        expected_fn = case.get("footnotes")
        if expected_fn is not None and expected_fn != case_footnote_count:
            self.log_warning(case_id, "", f"Manifest footnotes ({expected_fn}) != actual footnotes in expected.jsonl ({case_footnote_count})")

    def validate_checkable_claim(self, case_id: str, record: dict, library_dir: Path):
        claim_id = record.get("claim_id", "")
        expected = record.get("expected", "")
        valid_expecteds = {"supported", "contradicted", "no_source", "paraphrase_flag"}
        if expected not in valid_expecteds:
            self.log_error(case_id, claim_id, f"Invalid expected value '{expected}'. Must be one of {valid_expecteds}")

        context = record.get("context", "")
        if not context:
            self.log_warning(case_id, claim_id, "Context sentence is missing or empty")

        if expected == "supported":
            evidences = record.get("evidence", [])
            if not evidences or not isinstance(evidences, list):
                self.log_error(case_id, claim_id, "Supported claim must contain non-empty 'evidence' list")
                return

            for ev in evidences:
                source_id = ev.get("source_id", "")
                src_file = find_source_file(library_dir, source_id)
                if not src_file:
                    self.log_error(case_id, claim_id, f"Evidence source_id '{source_id}' not found in library {library_dir}")
                    continue

                locator = ev.get("locator", {})
                line_val = locator.get("value")
                if not line_val or not isinstance(line_val, int):
                    self.log_error(case_id, claim_id, f"Locator value must be a positive 1-based integer, got {line_val}")
                    continue

                lines = read_source_lines(src_file)
                if line_val < 1 or line_val > len(lines):
                    self.log_error(case_id, claim_id, f"Line locator {line_val} out of bounds (file has {len(lines)} lines)")
                    continue

                source_line = lines[line_val - 1]
                ev_quote = ev.get("quote", "")
                if not ev_quote:
                    self.log_error(case_id, claim_id, "Evidence quote is empty")
                    continue

                norm_quote = normalize_text(ev_quote)
                norm_source = normalize_text(source_line)

                if norm_quote not in norm_source:
                    self.log_error(case_id, claim_id, f"Evidence quote not verbatim in source line {line_val}.\n  Evidence: '{norm_quote}'\n  Source  : '{norm_source}'")

        elif expected == "contradicted":
            evidences = record.get("evidence", [])
            if not evidences:
                self.log_warning(case_id, claim_id, "Contradicted claim should cite conflicting source line in 'evidence'")

        elif expected == "no_source":
            # Search full library to ensure quote/fact returns zero exact matches
            quote = record.get("quote", "")
            if quote and len(quote) > 3 and library_dir.is_dir():
                norm_quote = normalize_text(quote)
                for f in library_dir.iterdir():
                    if f.is_file() and f.suffix in [".md", ".txt"]:
                        content = normalize_text(f.read_text(encoding="utf-8", errors="replace"))
                        if norm_quote in content:
                            self.log_error(case_id, claim_id, f"no_source claim quote '{quote}' was found inside {f.name}!")

        elif expected == "paraphrase_flag":
            # Paraphrase should not be verbatim
            pass

    def validate_prose(self, case_id: str, record: dict):
        claim_id = record.get("claim_id", "")
        context = record.get("context", "")
        # not_checked prose must not contain digits or figures
        if re.search(r'\d', context):
            self.log_warning(case_id, claim_id, f"Prose marked 'not_checked' contains numbers: '{context}'")

    def validate_footnote(self, case_id: str, record: dict, library_dir: Path):
        claim_id = record.get("claim_id", "")
        expected = record.get("expected", "")
        source_id = record.get("source_id", "")

        if expected not in {"supported", "misattributed", "no_source"}:
            self.log_error(case_id, claim_id, f"Footnote expected value '{expected}' invalid. Must be supported/misattributed/no_source")

        if expected in {"supported", "misattributed"} and source_id:
            src_file = find_source_file(library_dir, source_id)
            if not src_file:
                self.log_error(case_id, claim_id, f"Footnote source_id '{source_id}' does not exist in library")

    def validate_dataset_distributions(self, cases: list):
        print("\n--- Summary of Counts & Distributions ---")
        print(f"Total Cases: {len(cases)}")
        print(f"  Splits : {dict(self.stats['cases_by_split'])}")
        print(f"  Domains: {dict(self.stats['cases_by_domain'])}")
        print(f"Checkable Claims: {self.stats['total_checkable']} (Expected >= 80 per language)")
        print(f"  Verdicts  : {dict(self.stats['claims_by_expected'])}")
        print(f"  Difficulty: {dict(self.stats['claims_by_difficulty'])}")
        print(f"Prose (not_checked): {self.stats['total_prose']} (Expected >= 20)")
        print(f"Footnotes: {self.stats['total_footnotes']} (Expected >= 12)")
        print(f"  Footnote Verdicts: {dict(self.stats['footnotes_by_expected'])}")

        # Check domain caps: no domain > 30% of core cases
        core_cases = self.stats["cases_by_split"]["dev"] + self.stats["cases_by_split"]["test"]
        if core_cases > 0:
            for domain, count in self.stats["cases_by_domain"].items():
                ratio = count / core_cases
                if ratio > 0.30:
                    self.log_warning("GLOBAL", "", f"Domain '{domain}' represents {ratio:.1%} of core cases (cap is 30%)")

    def sample_for_human_audit(self, output_path: Path):
        if not self.all_claims_for_audit:
            return
        sample_size = max(1, int(len(self.all_claims_for_audit) * self.sample_rate))
        sample = random.sample(self.all_claims_for_audit, sample_size)
        
        lines = [
            f"# CheckMato Human Audit Sample ({int(self.sample_rate*100)}% Random Sample)",
            f"Total sample size: {len(sample)} claims\n",
            "| Case ID | Claim ID | Context | Expected | Evidence Quote | Notes |",
            "|---|---|---|---|---|---|"
        ]
        for case_id, rec in sample:
            ev_quotes = "; ".join(ev.get("quote", "") for ev in rec.get("evidence", []))
            lines.append(f"| {case_id} | {rec.get('claim_id')} | {rec.get('context','').replace('|','/')} | {rec.get('expected')} | {ev_quotes.replace('|','/')} | {rec.get('notes','')} |")

        output_path.write_text("\n".join(lines), encoding="utf-8")
        print(f"\nGenerated human audit checklist for {len(sample)} claims at {output_path}")

def main():
    parser = argparse.ArgumentParser(description="Validate CheckMato evaluation dataset.")
    parser.add_argument("--dataset-dir", type=Path, required=True, help="Root directory of dataset or cases")
    parser.add_argument("--audit-sample", type=float, default=0.10, help="Sampling fraction for manual review (default 0.10)")
    parser.add_argument("--audit-output", type=Path, default=Path("audit_sample.md"), help="File to write audit sample markdown")
    args = parser.parse_args()

    validator = DatasetValidator(args.dataset_dir, sample_rate=args.audit_sample)
    success = validator.validate()

    if validator.warnings:
        print(f"\n[!] Warnings ({len(validator.warnings)}):")
        for w in validator.warnings[:20]:
            print(f"  {w}")
        if len(validator.warnings) > 20:
            print(f"  ... and {len(validator.warnings) - 20} more warnings")

    if validator.errors:
        print(f"\n[X] Validation Failed with {len(validator.errors)} errors:")
        for err in validator.errors[:30]:
            print(f"  {err}")
        if len(validator.errors) > 30:
            print(f"  ... and {len(validator.errors) - 30} more errors")
        sys.exit(1)
    else:
        print("\n[V] All acceptance checks PASSED successfully!")
        validator.sample_for_human_audit(args.audit_output)

if __name__ == "__main__":
    main()
