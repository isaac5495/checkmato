# CheckMato Evaluation Benchmark Dataset (English)

Version: 1.0 · 2026-10-28
Specification: DATASET_PLAN_EN.md

## Dataset Overview
- **Language**: English (`en`)
- **Core Cases**: 12 cases (8 `dev`, 4 `test`) across 5 domains:
  - Business: 3 cases (25.0%)
  - Science/Tech: 3 cases (25.0%)
  - Healthcare: 2 cases (16.7%)
  - Policy/Law: 2 cases (16.7%)
  - Social Science: 2 cases (16.7%)
  (Strictly complies with <= 30% per domain cap)
- **Adversarial Cases**: 8 cases in `adversarial` split covering value-only traps, lookalike names, parent/subsidiary traps, currency and unit mismatches, decade confusion, and paraphrased quotes.
- **Checkable Claims**: 80 claims in core cases:
  - `supported`: 60 (50% easy, 30% medium, 20% hard)
  - `contradicted`: 10
  - `no_source`: 6
  - `paraphrase_flag`: 4
- **Prose Claims**: 20 `not_checked` sentences (no figures/quotes)
- **Footnotes**: 12 footnotes (7 `supported`, 3 `misattributed`, 2 `no_source`)
- **Total Cases**: 20 cases

## Validation
Validated via `scripts/validate_dataset.py` with 100% acceptance pass.
