Landmark Trust Review
Historic brick façades were restored using period-accurate lime mortar.
