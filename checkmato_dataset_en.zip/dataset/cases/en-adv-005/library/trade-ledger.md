Sterling Oceanic Trade Financial Audit
Sterling Oceanic Trade booked European export revenue of €45 million in 2022.
Exchange rate volatility created minor hedging discrepancies during fiscal close.
