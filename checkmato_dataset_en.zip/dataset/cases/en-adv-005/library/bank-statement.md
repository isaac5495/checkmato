Commercial Banking Reconciliation
Foreign currency reserve accounts held sufficient balances for debt service.
