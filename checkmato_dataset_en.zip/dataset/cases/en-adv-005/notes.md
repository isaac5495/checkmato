Catalogue Item 5: Currency mismatch.
