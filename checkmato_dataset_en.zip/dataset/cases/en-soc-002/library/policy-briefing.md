Congressional Testimony and Policy Summary
Research Director Dr. Hannah Cole testified before the congressional workforce committee in July 2021.
Hannah Cole noted: vocational skill reinvestment establishes enduring foundations for multi-generational regional wealth.
