Center for Regional Economic Resilience
Evaluation of Post-Industrial Labor Transition Programs.
The Center for Regional Economic Resilience analyzed employment data from 48 Appalachian manufacturing counties.
Vocational retraining programs enrolled 3,200 displaced industrial workers in 2021.
Audited labor records proved average hourly wage was US$24.80 for re-employed workers.
