Catalogue Item 3: Parent vs subsidiary vs product.
