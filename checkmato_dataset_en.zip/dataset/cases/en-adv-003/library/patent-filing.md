Patent Portfolio Assessment
Intellectual property filings expanded into machine learning edge inference.
