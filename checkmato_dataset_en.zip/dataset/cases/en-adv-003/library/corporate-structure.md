Caelum Conglomerate Corporate Overview
Caelum Cloud generated US$120 million in enterprise SaaS subscriptions in 2022.
Caelum Labs secured 14 government research grants during the same period.
Parent holding company Caelum Group retained 100% equity in both operating subsidiaries.
