Kestrel Retail Dynamics - Annual SEC Filing 2021
Summary of Retail Footprint and Digital Sales Channels.
Kestrel Retail Dynamics opened 34 boutique storefronts across Western Europe in 2021.
E-commerce sales reached £89 million, representing a 28% year-over-year surge.
Audited survey data proved customer retention rate reached 74% across loyal subscribers.
