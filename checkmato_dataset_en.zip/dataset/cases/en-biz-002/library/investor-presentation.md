Investor Relations Deck 2021
Executive Leadership and Governance Updates.
Founder Sarah Jenkins appointed Liam Gallagher as Chief Operating Officer in April 2021.
Sarah Jenkins noted: sustainable retail triumph demands persistent omni-channel modernization.
