Oakhaven Municipal Housing Authority Fiscal Plan 2023
Capital Budget Allocations.
Oakhaven Municipal Housing Authority allocated US$78 million for affordable residential redevelopment in 2023.
The initial capital surplus for the municipal housing fund was verified at US$9.5 million.
Contingency reserves ensure ongoing liquidity for metropolitan infrastructure works.
