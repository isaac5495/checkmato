City Council Planning and Zoning Hearing Minutes
The municipal council approved the zoning ordinance revision on March 18, 2023.
Director Evelyn Shaw authorized the construction of 650 energy-efficient apartment units.
Evelyn Shaw remarked: accessible shelter serves as the fundamental cornerstone of civic community stability.
