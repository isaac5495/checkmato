Maritime Executive Journal Interview with Elena Rostova
Discussion on post-pandemic shipping lane stabilization.
Following three quarters of dock renovation, the terminal in Antwerp resumed full dry-dock operations in August 2022.
Our focus remains on sustainable bunkering fuel and digital cargo tracking.
