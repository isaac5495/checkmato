Annual Financial Review: Solis Marine Logistics
Overview of Global Shipping and Port Operations for Fiscal Year 2022.
Solis Marine Logistics reported gross revenue of US$142 million in 2022.
Strategic fleet acquisitions progressed rapidly throughout the second half of the fiscal cycle.
The company expanded its container fleet to 85 vessels by December 2022.
CEO Elena Rostova oversaw the opening of the Rotterdam logistics hub.
Operational audits verified that Solis Marine operated 68 commercial berths worldwide.
Following extensive infrastructure investments, port efficiency increased across all European terminals.
