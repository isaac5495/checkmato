Horizon Physics Lab Benchmark Report
Principal Scientist Dr. Vikram Sethi demonstrated two-qubit gate fidelity of 99.7%.
Zoe Washington recorded coherence time T1 of 185 microseconds across test arrays.
Under continuous dynamic decoupling microwave pulse sequences, quantum state readout error diminished to 0.45%.
