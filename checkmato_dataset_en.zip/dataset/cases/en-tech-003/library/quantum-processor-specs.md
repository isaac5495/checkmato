Horizon Quantum Labs Processor Data Sheet
Horizon Quantum Labs fabricated an 84-qubit superconducting quantum processor in 2023.
The processor dilution refrigerator maintained an operational base temperature of 14 millikelvin.
Coaxial wiring architecture maintains minimal thermal dissipation into the mixing chamber.
