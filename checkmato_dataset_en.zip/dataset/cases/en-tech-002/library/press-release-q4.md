Press Release - Q4 Telecom Technology Milestone
Priya Patel confirmed optical signal-to-noise ratio exceeded 26 dB under test conditions.
Commercial deployments with Nordic telecom carriers commence next quarter.
