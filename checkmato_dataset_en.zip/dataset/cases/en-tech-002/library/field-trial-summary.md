Subsea Transmission Field Trial Report
Lumina Optical Networks sustained 800 Gbps transmission across a 1,200-kilometer fiber link.
Field trials in the Scandinavian subsea corridor concluded on November 14, 2023.
After deploying active silicon-photonics amplification, spectral efficiency reached 6.4 bits per second per hertz across high-attenuation spans.
