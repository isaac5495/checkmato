Clinical Investigator Brochure v3
Principal Investigator Dr. Rachel Vance presented the findings at the European Neurology Congress.
Pharmacokinetic profile showed consistent biological clearance rates.
Patients receiving titrated morning doses showed sustained plasma concentration above 45 ng/mL throughout the 48-hour monitoring window.
