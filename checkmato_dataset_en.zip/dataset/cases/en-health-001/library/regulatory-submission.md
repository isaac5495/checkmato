Regulatory Briefing Package: European Medicines Agency
Severe adverse events occurred in only 1.4% of the active treatment group.
Safety endpoints were satisfied across all monitored age demographics.
