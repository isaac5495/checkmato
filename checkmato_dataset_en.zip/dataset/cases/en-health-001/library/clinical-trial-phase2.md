Aetheria Biopharma Clinical Protocol AB-401
Study Design and Participant Cohorts.
Aetheria Biopharma enrolled 420 patients in its Phase 2 clinical trial for AB-401.
Primary endpoint efficacy reached 68% symptom reduction at week 24.
Comparative statistics recorded placebo response at 18% across all trial cohorts.
