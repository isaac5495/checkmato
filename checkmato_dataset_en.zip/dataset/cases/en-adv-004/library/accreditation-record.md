Healthcare Licensing and Accreditation Registry
Vanguard Health Group acquired 24 outpatient diagnostic clinics across Ohio in 2021.
Vanguard Hospital operated an 80-bed acute surgical center in Columbus.
Both healthcare entities maintain separate state clinical licenses.
