State Board of Health Hospital Inspection
Operating theaters maintained full compliance with emergency surgical guidelines.
