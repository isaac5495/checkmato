Healthcare Systems Financial Footnote
Medicare reimbursement rates were adjusted in accordance with federal schedules.
