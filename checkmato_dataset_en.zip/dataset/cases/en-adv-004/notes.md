Catalogue Item 4: Lookalike name.
