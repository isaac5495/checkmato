Catalogue Item 1: Value-only trap.
