Regional Renewable Generation Audit
Arcturus Solar Facility generated 45,000 megawatt-hours during peak summer operations.
Borealis Wind Park produced 18,200 megawatt-hours over the same quarterly period.
