Operator Dispatch Log
Peak transmission curtailed 5% of excess solar output during thermal inversions.
