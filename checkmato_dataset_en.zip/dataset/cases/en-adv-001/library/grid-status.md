State Transmission Operator Grid Summary
Transmission interconnection voltage held constant across high-voltage substations.
