Catalogue Item 2: Same subject, different year.
