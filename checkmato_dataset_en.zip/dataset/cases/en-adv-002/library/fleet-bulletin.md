Aviation Safety Board Dispatch
Standard flight avionics protocols were strictly adhered to during initial rollout.
