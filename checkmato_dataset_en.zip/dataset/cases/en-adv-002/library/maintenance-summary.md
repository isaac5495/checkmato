Annual Airframe Maintenance Log
Rotor balancing diagnostics completed zero-vibration certification trials.
