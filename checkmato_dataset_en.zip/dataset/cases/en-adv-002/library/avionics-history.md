Helios Flight Systems Regulatory Archive
Helios Flight Systems achieved commercial transport airworthiness certification in 2018.
Helios Flight Systems achieved autonomous military drone clearance in 2021.
