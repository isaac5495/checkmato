Zephyr Freightways Second Quarter Financial Statement
Net quarterly freight revenue reached US$215 million in Q2 2023.
Cash flow from operations supported planned terminal depot expansion.
