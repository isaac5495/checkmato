Fleet Electrification Strategy Paper
Managing Director Arthur Pendelton signed an electric fleet acquisition pact in Chicago.
Fiona Gallagher reported diesel fuel consumption per cargo-ton dropped by 14%.
Following interstate route optimization using telematics telemetry, cross-country transit turnaround contracted to 54 hours.
