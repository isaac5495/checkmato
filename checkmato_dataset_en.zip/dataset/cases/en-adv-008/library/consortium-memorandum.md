Novus Materials Consortium Executive Memorandum
Novus Materials Consortium synthesized lightweight graphene composite aero-panels in 2023.
Consortium director Arthur Vance stated: molecular precision manufacturing reliably conquers aviation weight barriers.
