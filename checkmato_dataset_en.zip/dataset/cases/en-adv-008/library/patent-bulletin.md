Industrial Intellectual Property Bulletin
Composite material manufacturing processes were protected by international patents.
