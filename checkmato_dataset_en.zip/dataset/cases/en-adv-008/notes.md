Catalogue Item 8: Paraphrased quote trap.
