Transit Telemetry and Micro-Mobility Annex
Bicycle commute frequency rose to 3.8 trips per week among inner-city residents.
When micro-mobility lanes were extended continuously across municipal boundaries, multi-modal transfer delays dropped by 14 minutes per journey.
Dedicated lanes encouraged first-mile and last-mile scooter usage.
