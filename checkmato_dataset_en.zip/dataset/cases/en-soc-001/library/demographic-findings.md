Demographic Findings and Transit Survey
Public transit ridership among remote hybrid workers declined by 31% post-pandemic.
Lead researcher Prof. Kenneth Ward published the survey findings in November 2022.
Survey results recorded commuter satisfaction was 46% across suburban bus lines.
