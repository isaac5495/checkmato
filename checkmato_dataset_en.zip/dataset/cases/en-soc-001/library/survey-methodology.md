Institute for Urban Mobility Studies - Methodology Whitepaper
Commuter Sampling Protocol.
The Institute for Urban Mobility Studies surveyed 12,500 metropolitan commuters in autumn 2022.
Interviews covered both rail transit users and regional automobile commuters.
