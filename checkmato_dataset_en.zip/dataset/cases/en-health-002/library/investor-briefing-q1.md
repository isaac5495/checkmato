Valenta Therapeutics Investor Briefing Q1 2023
David Bradley confirmed regulatory submission fees totaled US$3.8 million in 2023.
Commercial partnerships anticipate European marketing authorization filings later this year.
