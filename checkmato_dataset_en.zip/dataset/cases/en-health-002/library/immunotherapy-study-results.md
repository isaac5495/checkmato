Valenta Oncology Clinical Results: Cohort 3B
Valenta Therapeutics reported 62% progression-free survival in advanced oncology cohorts.
A total of 310 participants were monitored across twelve hospital treatment centers.
Chief Medical Officer Dr. Miriam O'Connor published clinical findings in February 2023.
After continuous intravenous infusion combined with cytokine blockers, median duration of therapeutic response extended to 16.4 months.
