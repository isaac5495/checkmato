Data Safety Monitoring Board Biannual Review
No grade 4 toxicities were attributed directly to study drug administration.
Independent monitors recommended continuation without protocol amendment.
