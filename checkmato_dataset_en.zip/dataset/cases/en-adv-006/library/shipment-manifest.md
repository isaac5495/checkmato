Global Freight Dispatch Sheet
Precision sensor units were crated for overseas aerospace clients.
