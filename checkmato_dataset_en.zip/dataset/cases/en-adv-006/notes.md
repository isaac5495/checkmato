Catalogue Item 6: Unit / magnitude trap.
