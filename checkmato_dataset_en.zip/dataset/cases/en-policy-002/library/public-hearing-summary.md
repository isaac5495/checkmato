Public Hearing on Regional Aquifer Quotas
Agricultural stakeholder associations agreed to seasonal withdrawal limits.
Water rights adjudications concluded without contentious litigation.
