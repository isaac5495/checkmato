Annual Hydrology Audit and Infrastructure Report
Commissioner Gregory Bell instituted mandatory subterranean aquifer metering in June 2022.
Municipal leak detection sensors identified 380 major subsurface main fractures.
Rapid repairs restored pipeline integrity across western municipal districts.
