#!/usr/bin/env python3
"""
CheckMato Dataset Validator (validate_dataset.py)
Validates compliance with CheckMato Benchmark Dataset Plan (v1.0).

Checks performed:
1. Directory structure & manifest.jsonl integrity.
2. Per-case files: draft.md, library/ (3-8 sources), expected.jsonl.
3. Schema & ID uniqueness for claims and footnotes.
4. Verbatim evidence checking for 'supported' claims against source line locators.
5. Negative search for 'no_source' claims across the library.
6. Prose check for 'not_checked' claims (no digits or quote characters).
7. Footnote source resolution & attribution checks.
8. Distribution & balance checks (domains <= 30%, difficulty ratios, verdict counts).
9. Dev/Test split isolation checks (entity/case uniqueness).
10. Random 10% sample generation for human audit.
"""

import os
import sys
import json
import re
import argparse
import unicodedata
import random
from pathlib import Path
from typing import Dict, List, Any, Tuple, Optional

# Supported verdicts
CLAIM_VERDICTS = {"supported", "contradicted", "no_source", "not_checked", "paraphrase_flag"}
FOOTNOTE_VERDICTS = {"supported", "misattributed", "no_source"}
DIFFICULTIES = {"easy", "medium", "hard"}
VALID_SPLITS = {"dev", "test", "adversarial"}
DOMAINS = {"business", "social_science", "tech", "policy_law", "medical"}

# Regex for numbers and quotation marks in not_checked claims
NUM_PATTERN = re.compile(r"[\d零一二三四五六七八九十百千万亿两壹贰叁肆伍陆柒捌玖拾佰仟萬億]")
QUOTE_PATTERN = re.compile(r"[\"\'“”‘’「」『』]")

def normalize_text(text: str) -> str:
    """Normalize text for whitespace, punctuation and unicode compatibility."""
    if not text:
        return ""
    text = unicodedata.normalize("NFKC", text)
    # Collapse all whitespace sequences into single space
    text = re.sub(r"\s+", " ", text).strip()
    return text

class ValidationResult:
    def __init__(self):
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.stats: Dict[str, Any] = {
            "cases_count": 0,
            "splits": {},
            "domains": {},
            "claims_total": 0,
            "claims_by_verdict": {},
            "difficulty_dist": {},
            "footnotes_total": 0,
            "footnotes_by_verdict": {},
            "adversarial_cases": 0,
        }

    def add_error(self, case_id: str, message: str):
        self.errors.append(f"[{case_id}] ERROR: {message}")

    def add_warning(self, case_id: str, message: str):
        self.warnings.append(f"[{case_id}] WARNING: {message}")

    def is_passed(self) -> bool:
        return len(self.errors) == 0

class DatasetValidator:
    def __init__(self, dataset_dir: Path, verbose: bool = False):
        self.dataset_dir = dataset_dir
        self.verbose = verbose
        self.res = ValidationResult()

    def run(self) -> ValidationResult:
        if not self.dataset_dir.is_dir():
            self.res.add_error("GLOBAL", f"Dataset directory not found: {self.dataset_dir}")
            return self.res

        manifest_path = self.dataset_dir / "manifest.jsonl"
        if not manifest_path.is_file():
            self.res.add_error("GLOBAL", f"manifest.jsonl missing in {self.dataset_dir}")
            return self.res

        manifest_entries = self._validate_manifest(manifest_path)
        if not manifest_entries:
            return self.res

        # Validate each case
        all_claims_for_audit = []
        dev_entities = set()
        test_entities = set()

        for entry in manifest_entries:
            case_id = entry.get("case_id", "UNKNOWN")
            claims, footnotes = self._validate_case(entry)
            all_claims_for_audit.extend(claims)

            # Record split stats
            split = entry.get("split", "unknown")
            self.res.stats["splits"][split] = self.res.stats["splits"].get(split, 0) + 1
            domain = entry.get("domain", "unknown")
            self.res.stats["domains"][domain] = self.res.stats["domains"].get(domain, 0) + 1

            if split == "dev":
                dev_entities.add(case_id)
            elif split == "test":
                test_entities.add(case_id)

        # Check split leakage
        leakage = dev_entities.intersection(test_entities)
        if leakage:
            self.res.add_error("GLOBAL", f"Case ID / Entity leakage across dev and test splits: {leakage}")

        # Check distribution rules
        self._check_distribution_rules()

        return self.res

    def _validate_manifest(self, manifest_path: Path) -> List[Dict[str, Any]]:
        entries = []
        case_ids = set()
        with open(manifest_path, "r", encoding="utf-8") as f:
            for idx, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except Exception as e:
                    self.res.add_error("MANIFEST", f"Line {idx} invalid JSON: {e}")
                    continue

                case_id = entry.get("case_id")
                if not case_id:
                    self.res.add_error("MANIFEST", f"Line {idx} missing 'case_id'")
                    continue

                if case_id in case_ids:
                    self.res.add_error("MANIFEST", f"Duplicate case_id in manifest: {case_id}")
                case_ids.add(case_id)

                # Required manifest fields
                required_keys = ["language", "domain", "split", "draft", "library", "claims", "footnotes"]
                for rk in required_keys:
                    if rk not in entry:
                        self.res.add_error(case_id, f"Manifest missing required field '{rk}'")

                entries.append(entry)

        self.res.stats["cases_count"] = len(entries)
        return entries

    def _validate_case(self, entry: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        case_id = entry["case_id"]
        case_dir = self.dataset_dir / "cases" / case_id
        if not case_dir.is_dir():
            # Check relative to manifest draft path if not in standard cases/<id>
            draft_path = self.dataset_dir / entry.get("draft", "")
            case_dir = draft_path.parent

        if not case_dir.is_dir():
            self.res.add_error(case_id, f"Case directory not found: {case_dir}")
            return [], []

        # Check draft.md
        draft_file = case_dir / "draft.md"
        if not draft_file.is_file():
            self.res.add_error(case_id, f"draft.md missing in {case_dir}")

        # Check library
        library_dir = case_dir / "library"
        if not library_dir.is_dir():
            self.res.add_error(case_id, f"library directory missing in {case_dir}")
            sources = {}
        else:
            sources = self._load_sources(case_id, library_dir)
            source_count = len(sources)
            if source_count < 3 or source_count > 8:
                self.res.add_warning(case_id, f"Library has {source_count} sources (expected 3-8 per brief)")

        # Check expected.jsonl
        expected_file = case_dir / "expected.jsonl"
        if not expected_file.is_file():
            self.res.add_error(case_id, f"expected.jsonl missing in {case_dir}")
            return [], []

        claims, footnotes = self._validate_expected_records(case_id, expected_file, sources)

        # Cross check manifest claimed counts
        if entry.get("claims") is not None and entry["claims"] != len(claims):
            self.res.add_warning(case_id, f"Manifest claims count ({entry['claims']}) != actual claims in expected.jsonl ({len(claims)})")
        if entry.get("footnotes") is not None and entry["footnotes"] != len(footnotes):
            self.res.add_warning(case_id, f"Manifest footnotes count ({entry['footnotes']}) != actual footnotes in expected.jsonl ({len(footnotes)})")

        return claims, footnotes

    def _load_sources(self, case_id: str, library_dir: Path) -> Dict[str, List[str]]:
        """Load text lines for all readable files in library/."""
        sources = {}
        for file_path in library_dir.iterdir():
            if file_path.is_file() and not file_path.name.startswith("."):
                stem = file_path.stem
                # Also index with full filename as alias
                aliases = [stem, file_path.name]
                lines = []
                try:
                    if file_path.suffix.lower() in [".md", ".txt", ".json", ".csv"]:
                        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                            lines = [line.rstrip("\r\n") for line in f]
                    elif file_path.suffix.lower() == ".pdf":
                        # Attempt extracting text via pypdf or pdfplumber if available
                        try:
                            import pypdf
                            reader = pypdf.PdfReader(str(file_path))
                            text = ""
                            for page in reader.pages:
                                text += (page.extract_text() or "") + "\n"
                            lines = text.splitlines()
                        except Exception as e:
                            self.res.add_warning(case_id, f"Could not read PDF text layer from {file_path.name}: {e}")
                    else:
                        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                            lines = [line.rstrip("\r\n") for line in f]
                except Exception as e:
                    self.res.add_error(case_id, f"Failed to read source {file_path.name}: {e}")

                for alias in aliases:
                    sources[alias] = lines
        return sources

    def _validate_expected_records(
        self, case_id: str, expected_file: Path, sources: Dict[str, List[str]]
    ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        claims = []
        footnotes = []
        claim_ids = set()

        with open(expected_file, "r", encoding="utf-8") as f:
            for line_idx, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except Exception as e:
                    self.res.add_error(case_id, f"expected.jsonl line {line_idx} invalid JSON: {e}")
                    continue

                cid = rec.get("claim_id")
                if not cid:
                    self.res.add_error(case_id, f"Record line {line_idx} missing claim_id")
                    continue
                if cid in claim_ids:
                    self.res.add_error(case_id, f"Duplicate claim_id '{cid}' in expected.jsonl")
                claim_ids.add(cid)

                ctype = rec.get("claim_type")
                if ctype == "footnote":
                    footnotes.append(rec)
                    self._validate_footnote(case_id, rec, sources)
                else:
                    claims.append(rec)
                    self._validate_claim(case_id, rec, sources)

        return claims, footnotes

    def _validate_claim(self, case_id: str, claim: Dict[str, Any], sources: Dict[str, List[str]]):
        cid = claim.get("claim_id", "UNKNOWN")
        expected = claim.get("expected")
        if expected not in CLAIM_VERDICTS:
            self.res.add_error(case_id, f"Claim {cid} invalid expected verdict '{expected}'. Must be one of {CLAIM_VERDICTS}")

        # Update stats
        self.res.stats["claims_total"] += 1
        self.res.stats["claims_by_verdict"][expected] = self.res.stats["claims_by_verdict"].get(expected, 0) + 1

        # Check not_checked rule: must not contain numbers or quote characters
        if expected == "not_checked":
            quote_text = claim.get("quote", "")
            ctx_text = claim.get("context", "")
            if NUM_PATTERN.search(quote_text) or NUM_PATTERN.search(ctx_text):
                self.res.add_error(case_id, f"Claim {cid} is 'not_checked' but contains digits or numbers: quote='{quote_text}'")
            if QUOTE_PATTERN.search(quote_text):
                self.res.add_error(case_id, f"Claim {cid} is 'not_checked' but contains quotation marks: quote='{quote_text}'")

        # Check difficulty for supported claims
        if expected == "supported":
            diff = claim.get("difficulty")
            if diff not in DIFFICULTIES:
                self.res.add_warning(case_id, f"Supported claim {cid} missing or invalid difficulty: '{diff}'")
            else:
                self.res.stats["difficulty_dist"][diff] = self.res.stats["difficulty_dist"].get(diff, 0) + 1

        # Verbatim evidence checks
        evidence_list = claim.get("evidence", [])
        if expected == "supported":
            if not evidence_list:
                self.res.add_error(case_id, f"Supported claim {cid} must have non-empty 'evidence'")
            else:
                for ev in evidence_list:
                    self._check_evidence_verbatim(case_id, cid, ev, sources)

        elif expected == "contradicted":
            if not evidence_list:
                self.res.add_warning(case_id, f"Contradicted claim {cid} has no evidence pointing to contradictory fact")
            else:
                for ev in evidence_list:
                    self._check_evidence_verbatim(case_id, cid, ev, sources, is_contradiction=True)

        elif expected == "no_source":
            # Search entire library to verify zero occurrences
            quote = claim.get("quote", "").strip()
            if quote and len(quote) >= 4:
                found_match = False
                norm_quote = normalize_text(quote)
                for src_name, lines in sources.items():
                    full_src = normalize_text(" ".join(lines))
                    if norm_quote in full_src:
                        self.res.add_error(case_id, f"Claim {cid} marked 'no_source' but quote '{quote}' found in library source '{src_name}'")
                        found_match = True
                        break

    def _check_evidence_verbatim(
        self, case_id: str, cid: str, ev: Dict[str, Any], sources: Dict[str, List[str]], is_contradiction: bool = False
    ):
        src_id = ev.get("source_id")
        if not src_id:
            self.res.add_error(case_id, f"Claim {cid} evidence missing 'source_id'")
            return

        # Find matching source in loaded sources
        matched_src = None
        for k in sources.keys():
            if k == src_id or k.startswith(f"{src_id}.") or src_id.startswith(k):
                matched_src = sources[k]
                break

        if matched_src is None:
            self.res.add_error(case_id, f"Claim {cid} references source_id '{src_id}' not found in library")
            return

        locator = ev.get("locator", {})
        ev_quote = ev.get("quote", "")
        if not ev_quote:
            self.res.add_error(case_id, f"Claim {cid} evidence missing verbatim 'quote'")
            return

        norm_ev_quote = normalize_text(ev_quote)

        # Check line locator
        if locator.get("kind") == "line":
            line_val = locator.get("value")
            if not isinstance(line_val, int) or line_val < 1:
                self.res.add_error(case_id, f"Claim {cid} evidence line locator value must be positive integer (got {line_val})")
            elif line_val > len(matched_src):
                self.res.add_error(case_id, f"Claim {cid} locator line {line_val} exceeds file length ({len(matched_src)} lines)")
            else:
                # Check around the line (+- 2 lines for multi-line quotes)
                start_l = max(0, line_val - 2)
                end_l = min(len(matched_src), line_val + 3)
                window_text = normalize_text(" ".join(matched_src[start_l:end_l]))
                if norm_ev_quote not in window_text:
                    # Also search whole file before failing
                    whole_file = normalize_text(" ".join(matched_src))
                    if norm_ev_quote in whole_file:
                        self.res.add_warning(
                            case_id,
                            f"Claim {cid} evidence quote found in '{src_id}', but not near specified line {line_val}"
                        )
                    else:
                        self.res.add_error(
                            case_id,
                            f"Claim {cid} evidence quote '{ev_quote[:40]}...' not found verbatim in '{src_id}'"
                        )

    def _validate_footnote(self, case_id: str, fn: Dict[str, Any], sources: Dict[str, List[str]]):
        cid = fn.get("claim_id", "UNKNOWN")
        expected = fn.get("expected")
        if expected not in FOOTNOTE_VERDICTS:
            self.res.add_error(case_id, f"Footnote {cid} invalid expected verdict '{expected}'. Must be one of {FOOTNOTE_VERDICTS}")

        self.res.stats["footnotes_total"] += 1
        self.res.stats["footnotes_by_verdict"][expected] = self.res.stats["footnotes_by_verdict"].get(expected, 0) + 1

        required_fn_fields = ["ref", "anchor_quote", "def_text"]
        for rf in required_fn_fields:
            if not fn.get(rf):
                self.res.add_error(case_id, f"Footnote {cid} missing required field '{rf}'")

        src_id = fn.get("source_id")
        if expected in ["supported", "misattributed"]:
            if not src_id:
                self.res.add_error(case_id, f"Footnote {cid} ({expected}) requires 'source_id'")
            elif not any(k == src_id or k.startswith(f"{src_id}.") for k in sources.keys()):
                self.res.add_warning(case_id, f"Footnote {cid} references source_id '{src_id}' which does not match a library filename stem")

    def _check_distribution_rules(self):
        total_cases = self.res.stats["cases_count"]
        if total_cases == 0:
            return

        # Check domain distribution (no domain over 30% of core cases)
        for dom, count in self.res.stats["domains"].items():
            pct = count / total_cases
            if pct > 0.35: # slight tolerance for small integer counts
                self.res.add_warning("BALANCE", f"Domain '{dom}' accounts for {pct:.1%} of cases (cap is 30%)")

        # Check difficulty distribution for supported claims
        sup_count = sum(self.res.stats["difficulty_dist"].values())
        if sup_count >= 10:
            easy_pct = self.res.stats["difficulty_dist"].get("easy", 0) / sup_count
            med_pct = self.res.stats["difficulty_dist"].get("medium", 0) / sup_count
            hard_pct = self.res.stats["difficulty_dist"].get("hard", 0) / sup_count
            if not (0.35 <= easy_pct <= 0.65):
                self.res.add_warning("BALANCE", f"Easy difficulty is {easy_pct:.1%} (target ~50%)")
            if not (0.15 <= med_pct <= 0.45):
                self.res.add_warning("BALANCE", f"Medium difficulty is {med_pct:.1%} (target ~30%)")
            if not (0.10 <= hard_pct <= 0.35):
                self.res.add_warning("BALANCE", f"Hard difficulty is {hard_pct:.1%} (target ~20%)")

def select_audit_sample(dataset_dir: Path, sample_rate: float = 0.10, seed: int = 42) -> List[Dict[str, Any]]:
    """Select a reproducible 10% sample of all claims across all cases for human review."""
    random.seed(seed)
    all_claims = []
    manifest_path = dataset_dir / "manifest.jsonl"
    if not manifest_path.is_file():
        return []

    with open(manifest_path, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            entry = json.loads(line)
            case_id = entry["case_id"]
            exp_file = dataset_dir / "cases" / case_id / "expected.jsonl"
            if exp_file.is_file():
                with open(exp_file, "r", encoding="utf-8") as ef:
                    for eline in ef:
                        if not eline.strip():
                            continue
                        rec = json.loads(eline)
                        rec["_case_id"] = case_id
                        all_claims.append(rec)

    sample_size = max(1, int(len(all_claims) * sample_rate))
    return random.sample(all_claims, sample_size)

def main():
    parser = argparse.ArgumentParser(description="CheckMato Dataset Acceptance & QA Validator")
    parser.add_argument("--dataset_dir", type=str, default="dataset", help="Path to dataset root folder")
    parser.add_argument("--audit_sample", action="store_true", help="Print random 10% sample for human audit")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for audit sampling")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose logging")
    args = parser.parse_args()

    ds_path = Path(args.dataset_dir)
    print(f"=== CheckMato Dataset QA & Acceptance Validator ===")
    print(f"Dataset root: {ds_path.resolve()}\n")

    validator = DatasetValidator(ds_path, verbose=args.verbose)
    res = validator.run()

    # Print summary statistics
    print("--- Summary Statistics ---")
    print(f"Total Cases: {res.stats['cases_count']}")
    print(f"Splits: {res.stats['splits']}")
    print(f"Domains: {res.stats['domains']}")
    print(f"Total Claims: {res.stats['claims_total']}")
    print(f"Claims by Verdict: {res.stats['claims_by_verdict']}")
    print(f"Difficulty (Supported): {res.stats['difficulty_dist']}")
    print(f"Total Footnotes: {res.stats['footnotes_total']}")
    print(f"Footnotes by Verdict: {res.stats['footnotes_by_verdict']}")
    print("--------------------------\n")

    if res.warnings:
        print(f"⚠️  {len(res.warnings)} WARNINGS:")
        for w in res.warnings:
            print(f"  - {w}")
        print()

    if res.errors:
        print(f"❌  {len(res.errors)} ERRORS FOUND:")
        for err in res.errors:
            print(f"  - {err}")
        print("\nResult: REJECTED (fix errors above before accepting)")
        sys.exit(1)
    else:
        print("✅  PASSED: Dataset schema and evidence locators are valid.")

    if args.audit_sample:
        print("\n--- 10% Human Review Audit Sample ---")
        samples = select_audit_sample(ds_path, sample_rate=0.10, seed=args.seed)
        for i, s in enumerate(samples, 1):
            print(f"[{i}] Case: {s.get('_case_id')} | Claim: {s.get('claim_id')} | Type: {s.get('claim_type')} | Verdict: {s.get('expected')}")
            print(f"    Quote: {s.get('quote') or s.get('anchor_quote')}")
            if s.get("evidence"):
                print(f"    Evidence: {s['evidence']}")
            print()

if __name__ == "__main__":
    main()
