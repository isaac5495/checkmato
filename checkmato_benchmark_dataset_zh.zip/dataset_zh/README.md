# CheckMato 评测基准数据集（中文版 v1.0）

## 1. 数据集概览
本数据集严格依据《CheckMato 评测数据集 — 生成计划（中文）》（DATASET_PLAN_ZH.md v1.0）构建，用于评测 CheckMato 的「有资料来源依据」核查能力。
所有实体、公司、财务数字与事件均为人工虚构，无真实品牌、无真实隐私数据。

- **总案例数**：20 个
  - 核心案例：12 个（8 dev, 4 test）
  - 对抗案例：8 个（覆盖目录 1-15 难点与陷阱）
- **覆盖领域**：商业金融（business）、硬核科技（tech）、社会科学（social_science）、政策法规（policy_law）、生物医药（medical）。各领域占比均 ≤ 30%。
- **标注类型**：
  - `supported`（有依据，逐字引文对齐）
  - `contradicted`（与资料冲突，保留冲突证据）
  - `no_source`（资料库无提及，经全库检索确认）
  - `not_checked`（叙述性议论，严格无数字/无引号）
  - `paraphrase_flag`（改写引用）
  - `misattributed`（脚注挂错出处）

## 2. 目录结构
```
dataset_zh/
  manifest.jsonl
  README.md
  cases/
    zh-biz-001/
      draft.md
      library/
        annual-report-2019.md
        executive-interview.md
        press-release-2020.md
      expected.jsonl
    ...
```

## 3. 运行校验
运行根目录下的校验器执行验收测试：
```bash
python3 validate_dataset.py --dataset_dir dataset_zh --audit_sample
```
